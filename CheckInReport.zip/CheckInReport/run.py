from openpyxl import load_workbook
import re
import os

excelData = {}

class Student:
    def __init__(self,id,name):
        self.id = id
        self.name = name
        self.delayTime = 0
        self.absentTime = 0
        self.morningReadTime = 0
    
    def print(self):
        print(str(self.id)+':'+self.name+':'+ str(self.delayTime) +':' + str(self.absentTime) + ':'+ str(self.morningReadTime))


def decodeDelay(strs,stu):
    matchObj = re.search(r'迟到[：:][^\x00-\xff]*?[;；]', strs, re.M|re.I)

    if matchObj:
        delayStudents = matchObj.group()[3:-1].split(r'、')
        for item in delayStudents:
            stu[item].delayTime += 1
        

def decodeAbsence(strs,stu):
    matchObj = re.search(r'缺勤[：:][^\x00-\xff]*?[;；]', strs, re.M|re.I)

    if matchObj:
        absenceStudents = matchObj.group()[3:-1].split(r'、')
        for item in absenceStudents:
            print(stu[item].print())
            stu[item].absentTime += 1

def decodeMorningRead(strs,stu):
    matchObj = re.search(r'早读[：:][^\x00-\xff]*?[;；]', strs, re.M|re.I)

    if matchObj:
        absenceStudents = matchObj.group()[3:-1].split(r'、')
        for item in absenceStudents:
            print(stu[item].print())
            stu[item].morningReadTime += 1


def initMap(file):
    wb = load_workbook(file)
    std = {}
    for ws in wb:
        for i in range(4,ws.max_row + 1):
            id = ws.cell(row=i,column=1).value
            name = ws.cell(row=i,column=2).value
            std[name] = Student(id,name)

    return std


def readSource(file):
    beginFlag = False
    stu = initMap('Template.xlsx')

    wb = load_workbook(file)
    for ws in wb:
        for i in range(1,ws.max_row + 1):
            cell = ws.cell(row=i,column = 3)
            if cell.value == '学生出勤情况':
                beginFlag = True
                continue
            
            if cell.value == None:
                beginFlag = False
            
            if beginFlag:
                strs = cell.value
                if strs[-1] != ';' and strs[-1] != '；':
                    strs = strs + ';'

                decodeDelay(strs,stu)
                decodeAbsence(strs,stu)
                decodeMorningRead(strs,stu)

    excelData[os.path.basename(file).split('.')[0]] = stu
    for item in stu.values():
        item.print()

def readSources(rootdir):
    files = os.listdir(rootdir) #列出文件夹下所有的目录与文件
    for i in range(0,len(files)):
        path = os.path.join(rootdir,files[i])
        if os.path.isfile(path):
            readSource(path)



def writeReport(templatePath,reportPath):
    wb = load_workbook(templatePath)
    for ws in wb:
        beginIndex = 3
        for key in excelData:
            cell = ws.cell(row=2,column=beginIndex)
            cell.value = key

            for i in range(4, ws.max_row + 1):
                id = ws.cell(row=i,column=1).value
                name = ws.cell(row=i,column=2).value

                ws.cell(row=i,column=beginIndex).value = excelData[key][name].absentTime
                ws.cell(row=i,column=beginIndex + 1).value = excelData[key][name].delayTime
                ws.cell(row=i,column=beginIndex + 2).value = excelData[key][name].morningReadTime

            beginIndex += 3

    wb.save(reportPath)

if __name__ == "__main__":
    readSources('.\\source')
    writeReport('Template.xlsx','统计结果.xlsx')